export const apiVersion =
  process.env.NEXT_PUBLIC_SANITY_API_VERSION || '2024-01-01'

export const dataset = assertValue(
  process.env.NEXT_PUBLIC_SANITY_DATASET,
  'Missing environment variable: NEXT_PUBLIC_SANITY_DATASET'
)

export const projectId = assertValue(
  process.env.NEXT_PUBLIC_SANITY_PROJECT_ID,
  'Missing environment variable: NEXT_PUBLIC_SANITY_PROJECT_ID'
)

// Set to true once the Sanity project exists and content should come live
// from the CMS. Until then, pages fall back to local placeholder content
// so the site still renders a complete, on-brand preview.
const PLACEHOLDER_VALUES = new Set(['placeholder-project-id', 'your-project-id', ''])

export const sanityConfigured = Boolean(
  process.env.NEXT_PUBLIC_SANITY_PROJECT_ID &&
    !PLACEHOLDER_VALUES.has(process.env.NEXT_PUBLIC_SANITY_PROJECT_ID)
)

function assertValue<T>(v: T | undefined, errorMessage: string): T {
  if (v === undefined) {
    // Don't throw at import time in dev/preview without a project yet —
    // callers should check `sanityConfigured` before querying.
    return 'placeholder-project-id' as unknown as T
  }
  return v
}
